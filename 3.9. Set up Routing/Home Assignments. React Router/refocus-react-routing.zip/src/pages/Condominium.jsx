import React from "react";

const Condominium = () => {
    return <div>Condominium</div>;
};

export default Condominium;
