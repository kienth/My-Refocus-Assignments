import React from "react";

const Header = () => {
    return (
        <div className="app-bar">
            <h3>Home</h3>
            <h3>Blogs</h3>
            <h3>Contact Me</h3>
        </div>
    );
};

export default Header;
