import "./App.css";
import TaxCalculator from "./components/TaxCalculator";

function App() {
    return (
        <div className="App">
            <TaxCalculator />
        </div>
    );
}

export default App;
