import { useState } from "react";
import TaxRateSelector from "./TaxRateSelector";

const TaxCalculator = () => {
    const [income, setIncome] = useState(0);
    const [result, setResult] = useState(0);
    const [taxRate, setTaxRate] = useState(10);

    const [errorMessage, setErrorMessage] = useState("");

    const calculateResult = () => {
        if (!isNaN(income)) {
            if (income.length > 7) {
                setErrorMessage("Maximum of 7 digits only");
            } else {
                setErrorMessage("");
                setResult((income * taxRate) / 100);
            }
        } else {
            setErrorMessage("Please input numbers only");
        }
    };

    return (
        <div className="container">
            <h1>Tax Calculator</h1>
            <h2>Tax Result: {result}</h2>
            <div className="form-group">
                <label for="income">Income:</label>
                <input
                    type="text"
                    id="income"
                    name="income"
                    defaultValue={income}
                    style={{ width: "-webkit-fill-available" }}
                    onChange={(e) => setIncome(e.target.value)}
                />
            </div>
            <TaxRateSelector props={{ taxRate, setTaxRate }} />

            {/* --- Start task 1 where tax rate was 20% ---*/}

            {/* <button onClick={() => setResult((income * 20) / 100)}>
                Calculate my Income Tax
            </button> */}

            {/* --- End task 1 where tax rate was 20% ---*/}

            <button onClick={() => calculateResult()}>
                Calculate my Income Tax
            </button>
            <br />
            <p className="errorMessage">{errorMessage}</p>
        </div>
    );
};

export default TaxCalculator;
