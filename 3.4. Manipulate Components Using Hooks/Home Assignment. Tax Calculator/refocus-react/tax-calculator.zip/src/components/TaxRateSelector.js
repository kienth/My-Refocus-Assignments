import React from "react";

const TaxRateSelector = ({ props }) => {
    return (
        <div className="form-group">
            <label for="taxRate">Tax Rate:</label>
            <select
                id="taxRate"
                name="taxRate"
                defaultValue={props.taxRate}
                onChange={(e) => props.setTaxRate(e.target.value)}
                required
            >
                <option value="10">10%</option>
                <option value="15">15%</option>
                <option value="20">20%</option>
                <option value="30">30%</option>
            </select>
        </div>
    );
};

export default TaxRateSelector;
