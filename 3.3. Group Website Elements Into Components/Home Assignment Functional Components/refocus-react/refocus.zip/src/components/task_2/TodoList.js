import React, { useState } from "react";
import TodoItem from "./TodoItem";

function TodoList() {
    const [listArray, setListArray] = useState([
        { id: 1, item: "Brush my Teeth", isComplete: false },
        { id: 2, item: "Meditate and Exercise", isComplete: false },
        { id: 3, item: "Make a To-Do List", isComplete: false },
    ]);

    return (
        <ul id="myUL">
            {listArray.map((item) => {
                return (
                    <li
                        style={{
                            display: "flex",
                            justifyContent: "space-between",
                        }}
                        className={item.isComplete ? "checked" : ""}
                    >
                        <TodoItem item={item} setListArray={setListArray} />
                    </li>
                );
            })}
        </ul>
    );
}

export default TodoList;
