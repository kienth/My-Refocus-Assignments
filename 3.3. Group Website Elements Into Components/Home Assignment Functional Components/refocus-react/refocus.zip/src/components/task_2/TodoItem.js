import React from "react";

function TodoItem({ item, setListArray }) {
    return (
        <>
            <input
                type="checkbox"
                class="styled-checkbox"
                checked={item.isComplete ? "checked" : ""}
                onClick={() => {
                    setListArray((prevList) =>
                        prevList.map((prev) => {
                            if (prev.id === item.id) {
                                return {
                                    ...prev,
                                    isComplete: !item.isComplete,
                                };
                            }
                            return prev;
                        })
                    );
                }}
            />
            <label for="myCheckbox">
                {item.isComplete ? <del>{item.item}</del> : item.item}
            </label>
            <span
                className="close"
                onClick={() => {
                    setListArray((prevList) =>
                        prevList.filter((prev) => prev.id !== item.id)
                    );
                }}
            >
                ×
            </span>
        </>
    );
}

export default TodoItem;
