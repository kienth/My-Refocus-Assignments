import React from "react";
import Input from "./Input";
import Button from "./Button";

function SearchBar() {
    return (
        <div className="searchBar">
            <Input />
            <Button />
        </div>
    );
}

export default SearchBar;
