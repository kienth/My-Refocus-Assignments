import React from "react";
import Input from "./Input";
import Button from "./Button";

function SearchBar() {
    return (
        <div id="myDIV" className="header">
            <h2 style={{ margin: "5px" }}>Search Bar & Todo List Activity</h2>
            <Input />
            <Button />
        </div>
    );
}

export default SearchBar;
