import React from "react";

function Button() {
    return <button className="addBtn">Search</button>;
}

export default Button;
