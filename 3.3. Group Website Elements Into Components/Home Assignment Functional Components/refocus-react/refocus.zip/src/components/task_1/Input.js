import React from "react";

function Input() {
    return <input type="text" id="myInput" placeholder="Search..." />;
}
export default Input;
