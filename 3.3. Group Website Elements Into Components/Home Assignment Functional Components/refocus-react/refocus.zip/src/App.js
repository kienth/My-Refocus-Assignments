import "./App.css";
import SearchBar from "./components/task_1/SearchBar";
import TodoList from "./components/task_2/TodoList";

function App() {
    return (
        <div className="App">
            <SearchBar />
            <TodoList />
        </div>
    );
}

export default App;
