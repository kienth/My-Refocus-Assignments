import { Upload } from "upload-js";
export const uploadImage = Upload({
  apiKey: "public_kW15bJuCbMFmcHHLgofRqvjCpFCT",
});
